'use strict';

var gulp         = require('gulp'),
    sass         = require('gulp-sass'),
    cleanCSS     = require('gulp-clean-css'),
    htmlmin      = require('gulp-htmlmin'),
    rename       = require('gulp-rename'),
    uglify       = require('gulp-uglify'),
    browserSync  = require('browser-sync'),
    sourcemaps   = require('gulp-sourcemaps'),
    clean        = require('gulp-clean'),
    autoprefixer = require('gulp-autoprefixer'),
    include      = require('gulp-include'),
    fileinclude  = require('gulp-file-include'),
    gutil        = require('gulp-util'),
    path         = require('path'),
    watch        = require('gulp-watch'),
    rename       = require('gulp-rename'),
    concat       = require('gulp-concat');
    
/*
* global variables
*/

var modules_dir_css  = ['src/scss/custom-modules/**/*.scss'];
var modules_dir_js   = ['src/js/custom-modules/**/*.js'];

var template_dir_css = ['src/scss/templates/**/*.scss'];
var template_dir_js  = ['src/js/templates/**/*.js'];

var allConvertJs     = ['src/js/base/**/*.js', 'src/js/components/**/*.js', 'src/js/layout/**/*.js', 'src/js/vendors/**/*.js'];
var allConvertScss   = ['src/scss/base/**/*.scss', 'src/scss/components/**/*.scss', 'src/scss/helpers/**/*.scss', 'src/scss/layout/**/*.scss', 'src/scss/utils/**/*.scss', 'src/scss/vendors/**/*.scss'];

/*
* Identify user
*/

var user=process.argv[3];
    if(user==undefined) {
        user="global";
}

/*
* ###################################
*/

/*
* Reload
*/

gulp.task('reload', () => {
    browserSync.reload();
})

/*
* ###################################
*/

/*
* Serve
*/

gulp.task('serve', () => {
    browserSync({
        server: 'src'
    })
});

/*
* ###################################
*/

/*
* Clean
*/

gulp.task('clean', () => {
    gulp.src(['./build/' + user])
        .pipe(clean(
            {
                force : true, 
                read : false
            }
        ));
});

/*
* ###################################
*/

/*
* Modules convert sass and js
*/

gulp.task('modules_dir_css', () => {
    var versionDate = new Date();
    gulp.src(modules_dir_css)
    .pipe(rename( (path) => {
        path.dirname=path.dirname+"/css";
    }))
    .pipe(sass())
    .pipe(gulp.dest('build/' + user + '/modules/'));
});

gulp.task('modules_dir_js', () => {
    var versionDate = new Date();
    gulp.src(modules_dir_js)
    .pipe(rename( (path) => {
        path.dirname=path.dirname + "/js";
      }))
    .pipe(gulp.dest('build/' + user + '/modules/'));
});

/*
* ###################################
*/

/*
* Templates convert sass and js
*/

gulp.task('template_dir_css', () => {
    var versionDate = new Date();
    gulp.src(template_dir_css)
    .pipe(rename( (path) => {
        path.dirname=path.dirname+"/css";
    }))
    .pipe(sass())
    .pipe(gulp.dest('build/' + user + '/templates/'));
});

gulp.task('template_dir_js', () => {
    var versionDate = new Date();
    gulp.src(template_dir_js)
    .pipe(rename( (path) => {
        path.dirname=path.dirname+"/js";
      }))
    .pipe(gulp.dest('build/' + user + '/templates/'));
});

/*
* ###################################
*/


/*
* Compile all js
*/

gulp.task('allConvertJs', () => {
    var versionDate = new Date();
    gulp.src(allConvertJs)
        .pipe(gulp.dest('build/'+ user + '/js/'));
})

/*
* ###################################
*/


/*
* Compile all js
*/

gulp.task('allConvertScss', () => {
    var versionDate = new Date();
    gulp.src(allConvertScss)
        .pipe(sass())
        .pipe(gulp.dest('build/' + user + '/css/'))
        .pipe(concat('main.css')).pipe(gulp.dest('build/' + user + '/connected_styles'))
})

/*
* ###################################
*/

gulp.task('default', ['modules_dir_css', 'modules_dir_js', 'template_dir_css', 'template_dir_js', 'allConvertJs', 'allConvertScss'], () => {
    watch(modules_dir_css,  () => {
        gulp.start('modules_dir_css');
    }); 
    watch(modules_dir_js, () => {
        gulp.start('modules_dir_js');
    });
    watch(template_dir_css, () => {
        gulp.start('template_dir_css');
    });
    watch(template_dir_js, () => {
        gulp.start('template_dir_js');
    });
    watch(allConvertJs, () => {
        gulp.start('allConvertJs');
    });
    watch(allConvertScss, () => {
        gulp.start('allConvertScss');
    });
});